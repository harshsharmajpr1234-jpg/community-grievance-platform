module.exports=[45153,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_files_%5Bname%5D_route_actions_0~6bmcj.js.map