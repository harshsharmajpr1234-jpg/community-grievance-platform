globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/t_iP2hKwGXDQCzLItOZIl/_buildManifest.js",
    "static/t_iP2hKwGXDQCzLItOZIl/_ssgManifest.js",
    "static/t_iP2hKwGXDQCzLItOZIl/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/06vwmd9tziq8j.js",
    "static/chunks/179_94jj.yc_5.js",
    "static/chunks/0s1x1s2xazj45.js",
    "static/chunks/0-rz9ow9tjtxp.js",
    "static/chunks/turbopack-0zh76tvm_vwcj.js"
  ]
};
