module.exports=[56740,(e,o,d)=>{}];

//# sourceMappingURL=0dk~_next-internal_server_app_api_admin_complaints_%5Bid%5D_update_route_actions_0g0.90v.js.map