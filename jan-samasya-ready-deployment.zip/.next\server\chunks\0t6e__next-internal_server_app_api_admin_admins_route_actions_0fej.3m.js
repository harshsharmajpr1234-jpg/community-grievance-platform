module.exports=[41724,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_admins_route_actions_0fej.3m.js.map