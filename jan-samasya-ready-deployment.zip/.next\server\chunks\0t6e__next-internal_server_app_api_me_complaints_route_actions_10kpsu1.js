module.exports=[34540,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_me_complaints_route_actions_10kpsu1.js.map