module.exports=[15928,(e,o,d)=>{}];

//# sourceMappingURL=12to_e-platform-development__next-internal_server_app_api_stats_route_actions_0~n06va.js.map