module.exports=[50152,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_register_page_actions_084ivwv.js.map