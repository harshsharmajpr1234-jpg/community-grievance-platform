module.exports=[6701,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app__global-error_page_actions_098p78p.js.map