module.exports=[18234,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_users_%5Bid%5D_route_actions_0t3ntck.js.map