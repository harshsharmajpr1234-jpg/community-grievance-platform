module.exports=[97524,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_complaints_route_actions_01xmq9k.js.map