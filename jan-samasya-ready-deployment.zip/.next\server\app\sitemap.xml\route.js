var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0jyoyzr._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0-x-_platform-development__next-internal_server_app_sitemap_xml_route_actions_0n.td7c.js")
R.m(54573)
module.exports=R.m(54573).exports
