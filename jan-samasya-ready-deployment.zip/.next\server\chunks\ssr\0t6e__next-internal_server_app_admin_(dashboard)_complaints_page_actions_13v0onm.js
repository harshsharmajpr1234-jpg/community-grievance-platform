module.exports=[37664,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_complaints_page_actions_13v0onm.js.map