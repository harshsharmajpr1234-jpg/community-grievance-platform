module.exports=[58209,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_about_page_actions_0gmokoj.js.map