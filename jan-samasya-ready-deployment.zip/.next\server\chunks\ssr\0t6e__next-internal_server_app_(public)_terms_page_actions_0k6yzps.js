module.exports=[88383,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_terms_page_actions_0k6yzps.js.map