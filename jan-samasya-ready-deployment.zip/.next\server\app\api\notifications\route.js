var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__0hulvgd._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0vfjr6~._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0v12c-5._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_notifications_route_actions_093j338.js")
R.m(67542)
module.exports=R.m(67542).exports
