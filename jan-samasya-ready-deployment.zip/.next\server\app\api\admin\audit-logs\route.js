var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/audit-logs/route.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_10i.4-e._.js")
R.c("server/chunks/[root-of-the-server]__0hvr_d~._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0v12c-5._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_admin_audit-logs_route_actions_0kbv1k8.js")
R.m(45434)
module.exports=R.m(45434).exports
