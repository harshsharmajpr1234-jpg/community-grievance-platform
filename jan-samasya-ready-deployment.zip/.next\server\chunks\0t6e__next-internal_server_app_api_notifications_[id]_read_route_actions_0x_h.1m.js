module.exports=[34480,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_notifications_%5Bid%5D_read_route_actions_0x_h.1m.js.map