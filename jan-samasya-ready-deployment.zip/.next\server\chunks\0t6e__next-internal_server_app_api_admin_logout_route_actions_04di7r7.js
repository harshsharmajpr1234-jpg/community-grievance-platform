module.exports=[40968,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_logout_route_actions_04di7r7.js.map