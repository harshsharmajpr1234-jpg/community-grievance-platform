module.exports=[33688,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_dashboard_page_actions_0rtsosd.js.map