module.exports=[45087,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_privacy_page_actions_11o86pt.js.map