module.exports=[33106,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_complaints_%5Bid%5D_feedback_route_actions_09nbplp.js.map