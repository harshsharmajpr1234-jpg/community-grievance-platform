module.exports=[94861,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_complaints_route_actions_00vdrtz.js.map