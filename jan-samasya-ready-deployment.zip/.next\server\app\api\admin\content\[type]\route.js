var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/content/[type]/route.js")
R.c("server/chunks/[root-of-the-server]__0k4x2g0._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0tgoku3._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0v12c-5._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_admin_content_[type]_route_actions_11pma4d.js")
R.m(14103)
module.exports=R.m(14103).exports
