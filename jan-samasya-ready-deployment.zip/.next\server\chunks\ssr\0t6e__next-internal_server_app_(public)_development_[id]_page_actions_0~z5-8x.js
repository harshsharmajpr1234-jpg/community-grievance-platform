module.exports=[8651,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_development_%5Bid%5D_page_actions_0~z5-8x.js.map