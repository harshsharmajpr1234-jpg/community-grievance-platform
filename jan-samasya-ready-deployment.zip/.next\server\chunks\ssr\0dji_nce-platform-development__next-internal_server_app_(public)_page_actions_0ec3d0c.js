module.exports=[5718,(a,b,c)=>{}];

//# sourceMappingURL=0dji_nce-platform-development__next-internal_server_app_%28public%29_page_actions_0ec3d0c.js.map