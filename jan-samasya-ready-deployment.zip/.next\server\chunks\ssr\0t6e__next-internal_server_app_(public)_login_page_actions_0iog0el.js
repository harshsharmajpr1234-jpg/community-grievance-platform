module.exports=[23391,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_login_page_actions_0iog0el.js.map