module.exports=[16941,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_notifications_route_actions_0d6kpb_.js.map