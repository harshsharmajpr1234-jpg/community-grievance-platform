var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/content/[type]/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0k4x2g0._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0x-m4dh._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0-_v6v3._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_admin_content_[type]_[id]_route_actions_011zduu.js")
R.m(92388)
module.exports=R.m(92388).exports
