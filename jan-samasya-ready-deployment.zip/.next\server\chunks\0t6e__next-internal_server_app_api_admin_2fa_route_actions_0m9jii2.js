module.exports=[17581,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_2fa_route_actions_0m9jii2.js.map