module.exports=[69001,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_me_route_actions_0hqy-i1.js.map