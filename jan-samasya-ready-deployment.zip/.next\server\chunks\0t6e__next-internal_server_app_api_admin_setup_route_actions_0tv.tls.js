module.exports=[83247,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_setup_route_actions_0tv.tls.js.map