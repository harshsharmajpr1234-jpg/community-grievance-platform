module.exports=[87279,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_reset-password_page_actions_0dkemcq.js.map