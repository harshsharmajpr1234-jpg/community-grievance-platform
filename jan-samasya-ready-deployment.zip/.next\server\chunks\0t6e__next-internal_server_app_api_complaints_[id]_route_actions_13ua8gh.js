module.exports=[24548,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_complaints_%5Bid%5D_route_actions_13ua8gh.js.map