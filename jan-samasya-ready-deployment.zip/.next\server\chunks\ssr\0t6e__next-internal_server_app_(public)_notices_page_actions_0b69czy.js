module.exports=[22695,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_notices_page_actions_0b69czy.js.map