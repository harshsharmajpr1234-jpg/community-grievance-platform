var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/[root-of-the-server]__0hulvgd._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0x4.p.~._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0-_v6v3._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_admin_settings_route_actions_02xs7wd.js")
R.m(25450)
module.exports=R.m(25450).exports
