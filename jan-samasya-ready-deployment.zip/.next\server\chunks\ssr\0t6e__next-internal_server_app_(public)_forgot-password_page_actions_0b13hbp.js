module.exports=[51473,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_forgot-password_page_actions_0b13hbp.js.map