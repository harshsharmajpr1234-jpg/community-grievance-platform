module.exports=[96860,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_audit-logs_route_actions_0kbv1k8.js.map