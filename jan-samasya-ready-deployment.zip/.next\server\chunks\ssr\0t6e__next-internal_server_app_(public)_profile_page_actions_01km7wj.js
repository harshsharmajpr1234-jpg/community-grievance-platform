module.exports=[5207,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_profile_page_actions_01km7wj.js.map