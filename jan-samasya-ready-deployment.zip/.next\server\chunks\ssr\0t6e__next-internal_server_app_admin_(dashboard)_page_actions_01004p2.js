module.exports=[52330,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_page_actions_01004p2.js.map