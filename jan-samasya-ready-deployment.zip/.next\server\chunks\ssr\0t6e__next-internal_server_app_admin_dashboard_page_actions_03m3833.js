module.exports=[67129,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_dashboard_page_actions_03m3833.js.map