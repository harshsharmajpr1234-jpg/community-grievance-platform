module.exports=[62507,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_dashboard_route_actions_087lzbu.js.map