var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__0yb7s6z._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/0q0f_-platform-development__next-internal_server_app_api_health_route_actions_0axo9fg.js")
R.m(36179)
module.exports=R.m(36179).exports
