module.exports=[53900,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_development_page_actions_0uunqxx.js.map