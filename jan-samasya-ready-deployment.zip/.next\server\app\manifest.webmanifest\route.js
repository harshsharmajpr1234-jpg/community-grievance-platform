var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__07pauip._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_manifest_webmanifest_route_actions_0cgwq8-.js")
R.m(7838)
module.exports=R.m(7838).exports
