module.exports=[55542,(a,b,c)=>{}];

//# sourceMappingURL=12to_e-platform-development__next-internal_server_app__not-found_page_actions_0866juy.js.map