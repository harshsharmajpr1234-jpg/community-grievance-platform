var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/services/route.js")
R.c("server/chunks/[root-of-the-server]__0k4x2g0._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_11aaepg._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0v12c-5._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_services_route_actions_03mf~it.js")
R.m(87688)
module.exports=R.m(87688).exports
