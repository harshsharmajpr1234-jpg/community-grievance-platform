var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0ehfn6u._.js")
R.c("server/chunks/ssr/052p_next_dist_esm_build_templates_app-page_0kclcw4.js")
R.c("server/chunks/ssr/[root-of-the-server]__10_wlu-._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0ke.v9y._.js")
R.c("server/chunks/ssr/0ujh_community-grievance-platform-development_src_app_global-error_tsx_04qoyqa._.js")
R.c("server/chunks/ssr/0t6e__next-internal_server_app__global-error_page_actions_098p78p.js")
R.m(28970)
module.exports=R.m(28970).exports
