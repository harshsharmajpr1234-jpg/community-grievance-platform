module.exports=[3217,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_auth_reset-password_route_actions_0mt0w6g.js.map