var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notices/route.js")
R.c("server/chunks/[root-of-the-server]__0k4x2g0._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0i0_1b4._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0v12c-5._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0-x-_platform-development__next-internal_server_app_api_notices_route_actions_0oks0oz.js")
R.m(90631)
module.exports=R.m(90631).exports
