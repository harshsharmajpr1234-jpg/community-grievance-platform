module.exports=[35992,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_contact_page_actions_12al778.js.map