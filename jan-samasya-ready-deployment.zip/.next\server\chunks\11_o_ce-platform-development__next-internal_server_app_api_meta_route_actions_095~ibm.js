module.exports=[74034,(e,o,d)=>{}];

//# sourceMappingURL=11_o_ce-platform-development__next-internal_server_app_api_meta_route_actions_095~ibm.js.map