module.exports=[50770,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_complaints_%5Bid%5D_documents_route_actions_0gpdfe9.js.map