module.exports=[17041,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_admins_%5Bid%5D_route_actions_0u8y3gk.js.map