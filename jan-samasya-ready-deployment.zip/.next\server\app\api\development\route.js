var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/development/route.js")
R.c("server/chunks/[root-of-the-server]__0k4x2g0._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_01jnqkl._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0v12c-5._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_development_route_actions_129_mlj.js")
R.m(7907)
module.exports=R.m(7907).exports
