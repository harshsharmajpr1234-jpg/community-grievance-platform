module.exports=[47054,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_change-password_route_actions_0pler00.js.map