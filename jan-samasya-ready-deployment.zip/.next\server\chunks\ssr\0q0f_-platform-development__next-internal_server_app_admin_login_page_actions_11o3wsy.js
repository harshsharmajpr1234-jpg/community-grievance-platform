module.exports=[20172,(a,b,c)=>{}];

//# sourceMappingURL=0q0f_-platform-development__next-internal_server_app_admin_login_page_actions_11o3wsy.js.map