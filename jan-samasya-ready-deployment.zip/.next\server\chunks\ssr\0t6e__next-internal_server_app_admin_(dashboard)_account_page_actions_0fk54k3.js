module.exports=[53874,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_account_page_actions_0fk54k3.js.map