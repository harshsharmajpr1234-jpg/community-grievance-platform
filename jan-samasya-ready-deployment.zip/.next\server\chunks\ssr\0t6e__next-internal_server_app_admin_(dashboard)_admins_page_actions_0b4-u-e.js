module.exports=[23138,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_admins_page_actions_0b4-u-e.js.map