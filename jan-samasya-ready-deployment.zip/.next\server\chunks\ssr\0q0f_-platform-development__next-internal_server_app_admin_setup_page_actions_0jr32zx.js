module.exports=[77244,(a,b,c)=>{}];

//# sourceMappingURL=0q0f_-platform-development__next-internal_server_app_admin_setup_page_actions_0jr32zx.js.map