module.exports=[57864,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_offline_page_actions_0~zj6--.js.map