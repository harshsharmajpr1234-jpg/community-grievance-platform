module.exports=[91475,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_settings_route_actions_02xs7wd.js.map