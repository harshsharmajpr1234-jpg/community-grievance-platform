module.exports=[26938,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_complaints_page_actions_0sf4044.js.map