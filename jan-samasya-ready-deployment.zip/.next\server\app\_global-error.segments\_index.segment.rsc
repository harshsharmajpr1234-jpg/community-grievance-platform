1:"$Sreact.fragment"
2:I[22243,["/_next/static/chunks/0xu.bqohansyq.js","/_next/static/chunks/05uvw~ugfqryx.js"],"default"]
3:I[92396,["/_next/static/chunks/0xu.bqohansyq.js","/_next/static/chunks/05uvw~ugfqryx.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"t_iP2hKwGXDQCzLItOZIl"}
