module.exports=[62203,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_auth_forgot-password_route_actions_11.gec-.js.map