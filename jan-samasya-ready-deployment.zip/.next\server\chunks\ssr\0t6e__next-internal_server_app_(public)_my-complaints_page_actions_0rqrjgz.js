module.exports=[76448,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_my-complaints_page_actions_0rqrjgz.js.map