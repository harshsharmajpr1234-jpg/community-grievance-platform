module.exports=[755,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_notifications_page_actions_07c.x~-.js.map