module.exports=[73513,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_storage_page_actions_0cvxb03.js.map