module.exports=[97146,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_storage_route_actions_07sxiyf.js.map