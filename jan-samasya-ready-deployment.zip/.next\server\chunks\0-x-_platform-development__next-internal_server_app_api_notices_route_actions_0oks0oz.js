module.exports=[72207,(e,o,d)=>{}];

//# sourceMappingURL=0-x-_platform-development__next-internal_server_app_api_notices_route_actions_0oks0oz.js.map