module.exports=[61669,(e,o,d)=>{}];

//# sourceMappingURL=0q0f_-platform-development__next-internal_server_app_api_health_route_actions_0axo9fg.js.map