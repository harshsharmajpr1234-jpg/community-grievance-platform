module.exports=[91145,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_complaints_%5Bid%5D_route_actions_0-iaqr7.js.map