module.exports=[15033,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_notices_%5Bid%5D_page_actions_0wy49op.js.map