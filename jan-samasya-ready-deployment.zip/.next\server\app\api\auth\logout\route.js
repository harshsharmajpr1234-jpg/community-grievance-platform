var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0~__tkg._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0-_v6v3._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_auth_logout_route_actions_0li6z74.js")
R.m(35165)
module.exports=R.m(35165).exports
