module.exports=[21184,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_services_route_actions_03mf~it.js.map