module.exports=[69648,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_settings_page_actions_0s2~-cg.js.map