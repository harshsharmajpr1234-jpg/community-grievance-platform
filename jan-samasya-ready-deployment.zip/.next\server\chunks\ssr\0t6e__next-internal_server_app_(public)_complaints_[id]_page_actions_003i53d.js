module.exports=[59571,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_complaints_%5Bid%5D_page_actions_003i53d.js.map