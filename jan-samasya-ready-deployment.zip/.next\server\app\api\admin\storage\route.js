var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/storage/route.js")
R.c("server/chunks/[root-of-the-server]__0i9_-~p._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0-_v6v3._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_admin_storage_route_actions_07sxiyf.js")
R.m(25413)
module.exports=R.m(25413).exports
