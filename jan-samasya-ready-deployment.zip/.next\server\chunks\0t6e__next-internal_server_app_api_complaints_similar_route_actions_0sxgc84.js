module.exports=[701,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_complaints_similar_route_actions_0sxgc84.js.map