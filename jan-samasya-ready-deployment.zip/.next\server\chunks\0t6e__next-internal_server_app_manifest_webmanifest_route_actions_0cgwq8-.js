module.exports=[43580,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_manifest_webmanifest_route_actions_0cgwq8-.js.map