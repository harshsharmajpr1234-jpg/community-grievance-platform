module.exports=[52026,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_content_%5Btype%5D_page_actions_0.404zp.js.map