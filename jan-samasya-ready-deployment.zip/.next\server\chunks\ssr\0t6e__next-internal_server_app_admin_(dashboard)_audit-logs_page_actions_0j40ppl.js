module.exports=[86574,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_audit-logs_page_actions_0j40ppl.js.map