module.exports=[95080,(a,b,c)=>{}];

//# sourceMappingURL=0dk~_next-internal_server_app_admin_%28dashboard%29_complaints_%5Bid%5D_page_actions_0xyxlw_.js.map