module.exports=[32801,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_community_page_actions_0efu0yr.js.map