module.exports=[44434,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_%28dashboard%29_notifications_page_actions_0n_kz2s.js.map