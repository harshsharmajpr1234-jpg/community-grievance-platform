module.exports=[10298,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_admin_change-password_page_actions_0ift5.1.js.map