module.exports=[98090,(a,b,c)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_%28public%29_services_page_actions_01~imx..js.map