module.exports=[42882,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_admin_content_%5Btype%5D_route_actions_11pma4d.js.map