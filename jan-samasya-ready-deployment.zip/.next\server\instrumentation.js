var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_src_0hmtcvh._.js")
R.m(83009)
module.exports=R.m(83009).exports
