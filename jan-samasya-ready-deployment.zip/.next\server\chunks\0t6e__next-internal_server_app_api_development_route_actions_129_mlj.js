module.exports=[18694,(e,o,d)=>{}];

//# sourceMappingURL=0t6e__next-internal_server_app_api_development_route_actions_129_mlj.js.map