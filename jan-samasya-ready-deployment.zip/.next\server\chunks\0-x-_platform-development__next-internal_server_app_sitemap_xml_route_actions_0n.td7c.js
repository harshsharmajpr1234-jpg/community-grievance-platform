module.exports=[65451,(e,o,d)=>{}];

//# sourceMappingURL=0-x-_platform-development__next-internal_server_app_sitemap_xml_route_actions_0n.td7c.js.map