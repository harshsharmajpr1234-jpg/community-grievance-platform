var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/read/route.js")
R.c("server/chunks/[root-of-the-server]__0hulvgd._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_10fxf8c._.js")
R.c("server/chunks/OneDrive_Desktop_community-grievance-platform-development_0-_v6v3._.js")
R.c("server/chunks/[root-of-the-server]__0a1kaz4._.js")
R.c("server/chunks/052p_next_0cenjqa._.js")
R.c("server/chunks/0t6e__next-internal_server_app_api_notifications_[id]_read_route_actions_0x_h.1m.js")
R.m(16181)
module.exports=R.m(16181).exports
