import { MongoClient, Db, Collection, Document } from "mongodb";

const dbName = process.env.MONGODB_DB_NAME || "janSamasyaDB";

declare global {
  // eslint-disable-next-line no-var
  var _mongoClientPromise: Promise<MongoClient> | undefined;
}

export async function getMongoClient(): Promise<MongoClient> {
  const isProduction =
    process.env.NODE_ENV === "production" ||
    Boolean(process.env.NETLIFY) ||
    Boolean(process.env.VERCEL);

  const mongoUri = process.env.MONGODB_URI;

  if (!mongoUri) {
    if (isProduction) {
      throw new Error("CONFIGURATION_ERROR: MONGODB_URI environment variable is missing in production environment.");
    }
    throw new Error("CONFIGURATION_ERROR: MONGODB_URI environment variable is missing.");
  }

  if (global._mongoClientPromise) {
    return global._mongoClientPromise;
  }

  const client = new MongoClient(mongoUri, {
    serverSelectionTimeoutMS: 10000,
    connectTimeoutMS: 10000,
    maxPoolSize: 10,
    minPoolSize: 0,
  });

  global._mongoClientPromise = client.connect();
  return global._mongoClientPromise;
}

export async function getDb(): Promise<Db> {
  const client = await getMongoClient();
  const name = process.env.MONGODB_DB_NAME || dbName;
  return client.db(name);
}

export async function getCollection<T extends Document = Document>(collectionName: string): Promise<Collection<T>> {
  const db = await getDb();
  return db.collection<T>(collectionName);
}

export async function pingDatabase(): Promise<boolean> {
  const isProduction =
    process.env.NODE_ENV === "production" ||
    Boolean(process.env.NETLIFY) ||
    Boolean(process.env.VERCEL);
  const mongoUri = process.env.MONGODB_URI;

  if (isProduction && !mongoUri) return false;
  try {
    const db = await getDb();
    const res = await db.command({ ping: 1 });
    return res.ok === 1;
  } catch {
    return false;
  }
}
